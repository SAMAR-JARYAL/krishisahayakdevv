import { Link, NavLink, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/state/auth";
import { Leaf } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="sticky top-0 z-40 w-full border-b bg-white/70 dark:bg-black/50 backdrop-blur supports-[backdrop-filter]:bg-white/50">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <span className="inline-flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
              <Leaf className="size-4" />
            </span>
            <span className="text-xl tracking-tight">KrishiSahayak</span>
          </Link>
          <nav className="hidden items-center gap-6 md:flex">
            <NavLink to="/how-it-works" className={({isActive})=>cn("text-sm text-muted-foreground hover:text-foreground", isActive && "text-foreground")}>How it works</NavLink>
            <NavLink to="/benefits" className={({isActive})=>cn("text-sm text-muted-foreground hover:text-foreground", isActive && "text-foreground")}>Benefits</NavLink>
            <NavLink to="/trust" className={({isActive})=>cn("text-sm text-muted-foreground hover:text-foreground", isActive && "text-foreground")}>Trust</NavLink>
          </nav>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <span className="hidden text-sm text-muted-foreground sm:inline">{user.email}</span>
                <Button variant="secondary" asChild>
                  <Link to="/dashboard">Dashboard</Link>
                </Button>
                <Button variant="outline" onClick={logout}>Log out</Button>
              </>
            ) : (
              <>
                <Button variant="outline" asChild>
                  <NavLink to="/login" className={({ isActive }) => cn(isActive && "bg-accent")}>Log in</NavLink>
                </Button>
                <Button asChild>
                  <NavLink to="/signup" className={({ isActive }) => cn(isActive && "opacity-90")}>Get Started</NavLink>
                </Button>
              </>
            )}
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t bg-background">
        <div className="container py-10 text-sm text-muted-foreground">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p>© {new Date().getFullYear()} KrishiSahayak. All rights reserved.</p>
            <div className="flex items-center gap-6">
              <a href="#how" className="hover:text-foreground">How it works</a>
              <a href="#benefits" className="hover:text-foreground">Benefits</a>
              <a href="#trust" className="hover:text-foreground">Trust</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
