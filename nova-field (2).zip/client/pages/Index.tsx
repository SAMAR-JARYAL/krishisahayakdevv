import { Button } from "@/components/ui/button";
import Layout from "@/components/Layout";
import { ArrowRight, Camera, Coins, FileSearch, Gauge, Globe, HandCoins, Lock, Satellite, ShieldCheck, Wallet2, WifiOff } from "lucide-react";
import { Link } from "react-router-dom";

export default function Index() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden border-b bg-gradient-to-br from-emerald-50 via-white to-white">
        <div className="container grid items-center gap-10 py-16 md:grid-cols-2 md:gap-16 lg:py-24">
          <div className="flex flex-col justify-center">
            <p className="text-sm font-semibold text-emerald-700">KrishiSahayak</p>
            <h1 className="mt-2 text-balance text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              Turn Your Farm Photos into Verified Carbon Credits
            </h1>
            <p className="mt-4 max-w-prose text-lg text-muted-foreground">
              Simple photos. AI verification. Blockchain-backed trust. Earn CO₂e credits by documenting regenerative practices — fast and transparently.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button size="lg" asChild>
                <Link to="/signup" className="inline-flex items-center gap-2">
                  Get Started <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#how">How it works</a>
              </Button>
            </div>
          </div>
          <ChartCard />
        </div>
      </section>

      {/* 3 simple steps */}
      <section id="how" className="container py-14">
        <h2 className="mb-6 text-2xl font-bold">3 simple steps</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <FeatureCard icon={<Camera className="size-5" />} title="Take geotagged photos" text="Capture 3 photos per plot — we auto-attach GPS & timestamp." />
          <FeatureCard icon={<Satellite className="size-5" />} title="AI + satellite verifies" text="Models confirm practices and match satellite signals." />
          <FeatureCard icon={<Coins className="size-5" />} title="Earn carbon payouts" text="Verified CO₂e turns into tradeable credits and payouts." />
        </div>
      </section>

      {/* Built for real world */}
      <section id="benefits" className="border-y bg-muted/20 py-14">
        <div className="container">
          <h2 className="mb-6 text-2xl font-bold">Built for real‑world conditions</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <FeatureCard icon={<HandCoins className="size-5" />} title="Quick payouts" text="Fast, secure payments with on-chain proof." />
            <FeatureCard icon={<Globe className="size-5" />} title="Local languages" text="Use the app in your own language." />
            <FeatureCard icon={<WifiOff className="size-5" />} title="Works offline" text="Capture evidence even without connectivity." />
          </div>
        </div>
      </section>

      {/* Carbon dashboard */}
      <section className="container grid items-center gap-10 py-16 md:grid-cols-2">
        <div>
          <h2 className="text-2xl font-bold">Carbon dashboard</h2>
          <p className="mt-3 max-w-prose text-muted-foreground">
            A single, transparent view of your credits, verified evidence, and history. Export ready for registries.
          </p>
          <ul className="mt-4 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
            <li>Per-plot, per-crop insights</li>
            <li>Simple reports</li>
            <li>Registry-ready</li>
          </ul>
          <div className="mt-6 flex gap-3">
            <Button>Join Free</Button>
            <Button variant="outline" asChild>
              <a href="#trust">Learn more</a>
            </Button>
          </div>
        </div>
        <ChartCard />
      </section>

      {/* Built-in accountability */}
      <section id="trust" className="border-y bg-muted/20 py-14">
        <div className="container">
          <h2 className="mb-6 text-2xl font-bold">Built‑in accountability</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <FeatureCard icon={<Lock className="size-5" />} title="Blockchain‑backed" text="Immutable proofs with transaction hashes." />
            <FeatureCard icon={<FileSearch className="size-5" />} title="Registry‑ready" text="Export PDF / JSON for any registry." />
            <FeatureCard icon={<ShieldCheck className="size-5" />} title="Open audit trail" text="Every step is timestamped and traceable." />
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-emerald-50 to-transparent" />
        <div className="container py-16">
          <div className="rounded-2xl border bg-card p-10 text-center shadow-sm">
            <h3 className="text-2xl font-bold">Start Earning from Your Land Today</h3>
            <p className="mt-2 text-muted-foreground">Join free. No phone changes required.</p>
            <div className="mt-6 flex justify-center">
              <Button size="lg" asChild>
                <Link to="/signup">Join Free</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

function FeatureCard({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-xl border bg-card p-5 shadow-sm transition-shadow hover:shadow-md">
      <div className="mb-3 inline-flex items-center justify-center rounded-md bg-primary/10 p-2 text-primary">{icon}</div>
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}

function ChartCard() {
  return (
    <div className="relative mx-auto w-full max-w-md rounded-2xl border bg-card p-6 shadow-xl">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">CO₂e credits earned</span>
        <span className="text-xs text-emerald-700">This season +12.6%</span>
      </div>
      <div className="mt-3 text-4xl font-bold">128.4</div>
      <div className="mt-6 grid grid-cols-12 items-end gap-1">
        {Array.from({ length: 12 }).map((_, i) => (
          <div key={i} className="rounded-md bg-emerald-500/90" style={{ height: `${20 + (i % 6) * 12}px` }} />
        ))}
      </div>
      <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground">
        <div className="h-2 w-16 rounded-full bg-emerald-500" /> Verified
        <div className="h-2 w-16 rounded-full bg-emerald-200" /> Pending
      </div>
    </div>
  );
}
