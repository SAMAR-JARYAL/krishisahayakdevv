import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Camera, Satellite, FileCheck, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function HowItWorks() {
  return (
    <Layout>
      <section className="border-b bg-gradient-to-b from-emerald-50/40 to-transparent">
        <div className="container py-12">
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl">How it works</h1>
          <p className="mt-2 max-w-prose text-muted-foreground">Three quick steps from field to verified, tradeable carbon credits.</p>
        </div>
      </section>
      <section className="container grid gap-6 py-12 sm:grid-cols-3">
        <Step icon={<Camera className="size-5" />} title="Capture" text="Take 3 geotagged photos per plot. Works offline; auto-syncs later." />
        <Step icon={<Satellite className="size-5" />} title="Verify" text="AI models + satellite confirm practices and estimate CO₂e." />
        <Step icon={<FileCheck className="size-5" />} title="Issue" text="Credits are issued to your wallet with full audit trail." />
      </section>
      <section className="container py-10">
        <div className="rounded-2xl border bg-card p-8 text-center shadow-sm">
          <h2 className="text-2xl font-semibold">Ready to try it?</h2>
          <p className="mt-2 text-muted-foreground">Join free and start earning.</p>
          <div className="mt-6 flex justify-center">
            <Button size="lg" asChild>
              <Link to="/signup" className="inline-flex items-center gap-2">Get started <ArrowRight className="size-4"/></Link>
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}

function Step({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-xl border bg-card p-6 shadow-sm transition-all hover:shadow-md">
      <div className="mb-3 inline-flex items-center justify-center rounded-md bg-primary/10 p-2 text-primary">{icon}</div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
