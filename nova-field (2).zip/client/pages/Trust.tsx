import Layout from "@/components/Layout";
import { FileSearch, Link2, Lock, ShieldCheck, Copy } from "lucide-react";

export default function Trust() {
  return (
    <Layout>
      <section className="border-b bg-gradient-to-b from-emerald-50/40 to-transparent">
        <div className="container py-12">
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Trust & Accountability</h1>
          <p className="mt-2 max-w-prose text-muted-foreground">Every action is auditable with timestamps and transaction hashes.</p>
        </div>
      </section>
      <section className="container grid gap-6 py-12 md:grid-cols-2">
        <div className="space-y-4">
          <TrustItem icon={<Lock className="size-5"/>} title="Blockchain‑backed proofs" text="Evidence hashes anchored on‑chain with public verification links."/>
          <TrustItem icon={<FileSearch className="size-5"/>} title="Registry‑ready exports" text="Generate PDF / JSON artifacts for any registry."/>
          <TrustItem icon={<ShieldCheck className="size-5"/>} title="Independent verification" text="AI + satellite + human review where needed."/>
        </div>
        <div className="rounded-xl border bg-card p-6 shadow-sm">
          <h3 className="text-lg font-semibold">Sample transaction</h3>
          <p className="mt-1 text-sm text-muted-foreground">#0x8f1...c2a — click to copy or view on chain.</p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm">
            <span>#0x8f1...c2a</span>
            <button className="text-primary">Copy</button>
            <a className="text-primary" href="#">View</a>
          </div>
        </div>
      </section>
    </Layout>
  );
}

function TrustItem({ icon, title, text }:{ icon: React.ReactNode; title: string; text: string }){
  return (
    <div className="rounded-xl border bg-card p-6 shadow-sm">
      <div className="mb-3 inline-flex items-center justify-center rounded-md bg-primary/10 p-2 text-primary">{icon}</div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{text}</p>
    </div>
  );
}
