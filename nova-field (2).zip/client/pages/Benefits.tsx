import Layout from "@/components/Layout";
import { HandCoins, Globe, WifiOff, ShieldCheck, Timer, Wallet, FileText } from "lucide-react";

export default function Benefits() {
  const items = [
    { icon: <HandCoins className="size-5"/>, title: "Quick payouts", text: "Fast, secure payments with on‑chain proof." },
    { icon: <Wallet className="size-5"/>, title: "Tradeable credits", text: "Use credits in-market or request payouts." },
    { icon: <Globe className="size-5"/>, title: "Local languages", text: "Hindi, English, and regional languages." },
    { icon: <WifiOff className="size-5"/>, title: "Works offline", text: "Capture anywhere; auto‑sync when online." },
    { icon: <ShieldCheck className="size-5"/>, title: "Trusted verification", text: "ML checks + satellite + registry-ready exports." },
    { icon: <FileText className="size-5"/>, title: "Simple reports", text: "PDF / JSON reports in one click." },
  ];
  return (
    <Layout>
      <section className="border-b bg-gradient-to-b from-emerald-50/40 to-transparent">
        <div className="container py-12">
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Benefits</h1>
          <p className="mt-2 max-w-prose text-muted-foreground">Purpose‑built for farmers and field operators working in real conditions.</p>
        </div>
      </section>
      <section className="container grid gap-6 py-12 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => (
          <div key={it.title} className="rounded-xl border bg-card p-6 shadow-sm transition-all hover:shadow-md">
            <div className="mb-3 inline-flex items-center justify-center rounded-md bg-primary/10 p-2 text-primary">{it.icon}</div>
            <h3 className="text-lg font-semibold">{it.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{it.text}</p>
          </div>
        ))}
      </section>
    </Layout>
  );
}
