import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Camera, Download, FileText, Globe, Loader2, MapPin, MoreVertical, Settings, ShieldCheck, Upload, Wallet, Wifi, WifiOff } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/state/auth";

export default function Dashboard() {
  const { user } = useAuth();
  const [lang, setLang] = useState<"en" | "hi">("en");
  const [queue, setQueue] = useState<number>(2);
  const [syncing, setSyncing] = useState(false);
  const online = typeof navigator !== "undefined" ? navigator.onLine : true;

  const kpis = useMemo(() => (
    [
      { label: "Total CO₂e (confirmed)", value: "2.3 tCO₂e" },
      { label: "Available Credits", value: "1.8" },
      { label: "Wallet Balance / Pending", value: "₹ 12,400 / ₹ 3,000" },
      { label: "Verification Confidence", value: "92%" },
    ]
  ), []);

  const plots = useMemo(() => (
    [
      { id: "P1", name: "North Block A", area: 0.5, crop: "Wheat", last: "08 Sep 2025", co2e: 0.6, confidence: "High", status: "Verified" },
      { id: "P2", name: "South Plot", area: 0.8, crop: "Rice", last: "01 Sep 2025", co2e: 0.9, confidence: "Medium", status: "Pending" },
      { id: "P3", name: "River Edge", area: 0.3, crop: "Maize", last: "03 Sep 2025", co2e: 0.4, confidence: "High", status: "Draft" },
    ]
  ), []);

  const startSync = async () => {
    setSyncing(true);
    await new Promise((r) => setTimeout(r, 1200));
    setQueue(0);
    setSyncing(false);
  };

  return (
    <Layout>
      <div className="container py-8">
        <Topbar
          name={user?.name ?? "Samar J."}
          shortId={user?.shortId ?? "KIS1234"}
          lang={lang}
          setLang={setLang}
          online={online}
          queue={queue}
        />

        <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k) => (
            <Card key={k.label}>
              <CardContent className="p-5">
                <p className="text-sm text-muted-foreground">{k.label}</p>
                <div className="mt-2 text-2xl font-bold">{k.value}</div>
              </CardContent>
            </Card>
          ))}
        </section>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Button size="lg" className="gap-2">
            <Camera className="size-4" /> Capture Plot
          </Button>
          <Button size="lg" variant="outline" onClick={startSync} disabled={!queue || syncing} className="gap-2">
            {syncing ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />} Sync Now {queue ? `(${queue})` : ''}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2"><FileText className="size-4" /> Export Report</Button>
        </div>

        <section className="mt-10 grid gap-6 md:grid-cols-3">
          <div className="md:col-span-1">
            <div className="rounded-xl border bg-card p-4">
              <div className="mb-3 flex items-center gap-2"><MapPin className="size-4 text-primary" /><span className="text-sm font-medium">Plots Map</span></div>
              <div className="relative h-56 w-full rounded-lg bg-gradient-to-br from-emerald-50 to-emerald-100">
                {plots.map((p, i) => (
                  <span key={p.id} className="absolute -translate-x-1/2 -translate-y-1/2">
                    <span
                      className={cn("block size-3 rounded-full border-2 border-white shadow", i % 2 ? "bg-emerald-500" : "bg-amber-500")}
                      style={{ left: `${20 + i * 25}%`, top: `${30 + (i % 3) * 20}%` }}
                      title={p.name}
                    />
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="md:col-span-2 grid gap-4">
            {plots.map((p) => (
              <PlotCard key={p.id} plot={p} />
            ))}
          </div>
        </section>

        <section className="mt-10 grid gap-6 lg:grid-cols-2">
          <Card>
            <CardContent className="p-5">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold">Wallet & Credits</h3>
                <Wallet className="size-5 text-primary" />
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <div className="text-xl font-semibold">₹ 12,400</div>
                  <div className="mt-3 flex gap-2"><Button size="sm">Sell Credits</Button><Button size="sm" variant="outline">Withdraw</Button></div>
                </div>
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Recent Transactions</p>
                  <ul className="mt-2 space-y-1 text-sm">
                    <li>#0xabc...f12 — +₹4,000</li>
                    <li>#0xdef...98a — -2 credits</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-5">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-semibold">Help & Training</h3>
                <Globe className="size-5 text-primary" />
              </div>
              <ul className="grid gap-3 sm:grid-cols-2">
                <li className="rounded-lg border p-3 text-sm">How to take 3 photos</li>
                <li className="rounded-lg border p-3 text-sm">How to check GPS</li>
                <li className="rounded-lg border p-3 text-sm">Ask Bot (multilingual)</li>
                <li className="rounded-lg border p-3 text-sm">Call/WhatsApp Support</li>
              </ul>
            </CardContent>
          </Card>
        </section>
      </div>
    </Layout>
  );
}

function Topbar({ name, shortId, lang, setLang, online, queue }:{ name: string; shortId: string; lang: "en"|"hi"; setLang: (l: "en"|"hi")=>void; online: boolean; queue: number; }){
  return (
    <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
      <div className="flex items-center gap-3">
        <span className="rounded-md bg-primary/10 px-3 py-1 text-sm font-medium text-primary">{name} — {shortId}</span>
        <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs", online ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700")}>{online ? <Wifi className="size-3"/> : <WifiOff className="size-3"/>}{online ? "Online" : `Offline: ${queue} to sync`}</span>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => setLang(lang === "en" ? "hi" : "en")}>{lang === "en" ? "English" : "हिंदी"}</Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="sm" className="gap-1"><Settings className="size-4"/> Quick settings</Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>App language</DropdownMenuItem>
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function PlotCard({ plot }: { plot: { id: string; name: string; area: number; crop: string; last: string; co2e: number; confidence: string; status: string; } }){
  return (
    <div className="rounded-xl border p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h4 className="text-base font-semibold">{plot.name} • {plot.id}</h4>
          <p className="text-sm text-muted-foreground">Area: {plot.area} ha | Crop: {plot.crop} | Last verified: {plot.last}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon"><MoreVertical className="size-4"/></Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Edit Plot Info</DropdownMenuItem>
            <DropdownMenuItem>Add Evidence</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <div className="mt-3 grid items-center gap-3 sm:grid-cols-3">
        <div>
          <p className="text-sm text-muted-foreground">CO₂e (this plot)</p>
          <div className="text-xl font-semibold">{plot.co2e} t <span className={cn("ml-2 rounded-full px-2 py-0.5 text-xs", plot.confidence === "High" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700")}>{plot.confidence}</span></div>
        </div>
        <div className="flex gap-2">
          {[1,2,3].map((i)=> (
            <div key={i} className="h-16 w-24 rounded-lg bg-muted"/>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="outline" className="gap-1"><FileText className="size-4"/> View Report</Button>
          <Button size="sm" className="gap-1"><ShieldCheck className="size-4"/> Request Verification</Button>
          <Button size="sm" variant="secondary" className="gap-1"><Wallet className="size-4"/> Request Payout</Button>
        </div>
      </div>
    </div>
  );
}
