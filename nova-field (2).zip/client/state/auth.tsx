import { createContext, useContext, useEffect, useMemo, useState } from "react";

type User = {
  id: string;
  email: string;
  name: string;
  shortId: string;
};

type AuthContextValue = {
  user: User | null;
  login: (payload: { email: string; password: string }) => Promise<void>;
  signup: (payload: { email: string; password: string }) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const STORAGE_KEY = "fusion-auth-user";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      // ignore
    }
  }, []);

  const persist = (u: User | null) => {
    setUser(u);
    try {
      if (u) localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
      else localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const login = async ({ email }: { email: string; password: string }) => {
    const base = email.split("@")[0] || "Farmer";
    const name = base.replace(/\W+/g, " ").replace(/^.|\s./g, (s) => s.toUpperCase()).trim() || "Farmer";
    const shortId = `KIS${Math.floor(1000 + Math.random()*9000)}`;
    const u: User = { id: crypto.randomUUID(), email, name, shortId };
    persist(u);
  };

  const signup = async ({ email }: { email: string; password: string }) => {
    const base = email.split("@")[0] || "Farmer";
    const name = base.replace(/\W+/g, " ").replace(/^.|\s./g, (s) => s.toUpperCase()).trim() || "Farmer";
    const shortId = `KIS${Math.floor(1000 + Math.random()*9000)}`;
    const u: User = { id: crypto.randomUUID(), email, name, shortId };
    persist(u);
  };

  const logout = () => persist(null);

  const value = useMemo(() => ({ user, login, signup, logout }), [user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
